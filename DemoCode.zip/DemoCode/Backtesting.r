if (!require(backtestGraphics)) {install.packages('backtestGraphics'); require(backtestGraphics)}
data(commodity)            ## load the commodity data in the package
backtestGraphics(x = commodity)
