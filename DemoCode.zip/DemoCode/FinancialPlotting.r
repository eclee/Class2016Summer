rm(list = ls())

if (!require(quantmod)) {install.packages('quantmod'); require(quantmod)}

?getSymbols

Sys.setenv(TZ="Asia/Taipei")
Date.from <- Sys.Date() - 256 * 5  # http://www.statmethods.net/input/dates.html
Date.to   <- Sys.Date()

getSymbols(Symbols = '^TWII', src = 'yahoo', from = Date.from, to = Date.to)

TWII <- getSymbols(Symbols = '^TWII', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)
class(TWSE)
TW0050 <- getSymbols(Symbols = '0050.TW', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)

TW0056 <- getSymbols(Symbols = '0056.TW', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)

chartSeries(TWSE)
chartSeries(TW0050)
chartSeries(TW0056)

## {fImport}
# if (!require(fImport)) {install.packages('fImport'); require(fImport)}
# 
# ?yahooSeries
# TWII <- yahooSeries('^TWII')
# class(TWII)
# head(TWII)
# TW0050 <- yahooSeries('0050.TW')
# class(TW0050)

## {dygraphs}
#   https://rstudio.github.io/dygraphs/index.html

if (!require(dygraphs)) {install.packages('dygraphs'); require(dygraphs)}

TWII_Close <- xts(Cl(TWII), order.by=index(TWII), frequency=365)
TW0050_Close <- xts(Cl(TW0050), order.by=index(TW0050), frequency=365)
head(TWII_Close)
head(TW0050_Close)


stocks <- cbind(TWII_Close, TW0050_Close)
str(stocks)
head(stocks)
tail(stocks)

dygraph(stocks, ylab="Close", 
        main="TWII and TW0050 Closing Stock Prices") %>%
  dySeries("TWII.Close",label="TWII") %>%
  dySeries("X0050.TW.Close",label="TW0050" , axis = 'y2') %>%   # https://rstudio.github.io/dygraphs/gallery-second-y-axis.html
  dyOptions(colors = c("blue","brown")) %>%
  dyRangeSelector()



## Getting Started with quantstrat
#   https://github.com/gyollin/quantstrat-tutorial.git
rm(list = ls())

symbols = c("^TWII", "0050.TW", "0056.TW")
Date.from <- Sys.Date() - 256 * 5  # http://www.statmethods.net/input/dates.html
Date.to   <- Sys.Date()

getSymbols(symbols, from=Date.from, to=Date.to, index.class="POSIXct")

symbols1 <- gsub('[[:punct:]]','', symbols)

for(symbol in symbols) {
  symbol_tmp <- gsub('[[:punct:]]','', symbol)    # http://www.endmemo.com/program/R/gsub.php
  # `^TWII`
  
  x <- get(symbol_tmp)
  x <- adjustOHLC(x,symbol.name=symbol)
  x <- to.weekly(x,indexAt='lastof',drop.time=TRUE)
  indexFormat(x) <- '%Y-%m-%d'
  colnames(x) <- gsub("x", symbol_tmp, colnames(x))
  assign(symbol_tmp, x)
}



