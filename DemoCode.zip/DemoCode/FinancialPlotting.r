rm(list = ls())

## {qauntmod} ####
if (!require(quantmod)) {install.packages('quantmod'); require(quantmod)}

# ?getSymbols

Sys.setenv(TZ="Asia/Taipei")
Date.from <- Sys.Date() - 256 * 5  # http://www.statmethods.net/input/dates.html
Date.to   <- Sys.Date()

getSymbols(Symbols = '^TWII', src = 'yahoo', from = Date.from, to = Date.to)

TWII <- getSymbols(Symbols = '^TWII', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)
# class(TWII)
TW0050 <- getSymbols(Symbols = '0050.TW', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)

TW0056 <- getSymbols(Symbols = '0056.TW', src = 'yahoo', from = Date.from, to = Date.to, auto.assign = FALSE)

chartSeries(TWII)
chartSeries(TW0050)
chartSeries(TW0056)


## {fImport} ####
# if (!require(fImport)) {install.packages('fImport'); require(fImport)}
 
# ?yahooSeries

# TWII <- yahooSeries('^TWII')
# class(TWII)
# head(TWII)

## {dygraphs}
#   https://rstudio.github.io/dygraphs/index.html

## {dygraphs} ####
if (!require(dygraphs)) {install.packages('dygraphs'); require(dygraphs)}

TWII_Close <- xts(Cl(TWII), order.by=index(TWII), frequency=365)
TW0050_Close <- xts(Cl(TW0050), order.by=index(TW0050), frequency=365)
# head(TWII_Close)
# head(TW0050_Close)

stocks <- cbind(TWII_Close, TW0050_Close)
# str(stocks)
# head(stocks)
# tail(stocks)

dygraph(stocks, ylab="Close", 
        main="TWII and TW0050 Closing Stock Prices") %>%
  dySeries("TWII.Close",label="TWII") %>%
  dySeries("X0050.TW.Close",label="TW0050" , axis = 'y2') %>%   # https://rstudio.github.io/dygraphs/gallery-second-y-axis.html
  dyOptions(colors = c("blue","brown")) %>%
  dyRangeSelector()